import json
import random
import numpy as np
import pandas as pd
import sklearn

from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

BASE = Path("working/extracted/IP_Identifier_Fine_Tuning/code")
OUTPUT = Path("results/predictions")
OUTPUT.mkdir(parents=True, exist_ok=True)

def load_jsonl(path):
    records = []
    with open(path, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip():
                records.append(json.loads(line))
    return pd.DataFrame(records)

train = load_jsonl(BASE / "dataset_train.jsonl")
test = load_jsonl(BASE / "dataset_test.jsonl")

X_train = train["prompt"].astype(str)
y_train = train["completion"].str.strip()

X_test = test["prompt"].astype(str)
y_test = test["completion"].str.strip()

model = Pipeline([
    ("tfidf", TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        sublinear_tf=True
    )),
    ("classifier", LogisticRegression(
        max_iter=2000,
        random_state=SEED
    ))
])

model.fit(X_train, y_train)

predictions = model.predict(X_test)

print("OFFLINE LOGISTIC REGRESSION RESULTS")
print("=" * 60)
print("Training records:", len(X_train))
print("Test records:", len(X_test))
print("Random seed:", SEED)
print("Scikit-learn:", sklearn.__version__)
print("TF-IDF vocabulary size:", len(model.named_steps["tfidf"].vocabulary_))

print("\nAccuracy:", accuracy_score(y_test, predictions))

print("\nClassification report:")
print(classification_report(
    y_test,
    predictions,
    labels=["negative", "positive"],
    zero_division=0
))

print("\nConfusion matrix (negative, positive):")
print(confusion_matrix(
    y_test,
    predictions,
    labels=["negative", "positive"]
))

results = pd.DataFrame({
    "prompt": X_test,
    "actual": y_test,
    "predicted": predictions,
    "correct": y_test.to_numpy() == predictions
})

results.to_csv(
    OUTPUT / "logistic_regression_predictions.csv",
    index=False
)

print("\nPrediction file:")
print(OUTPUT / "logistic_regression_predictions.csv")

print("\nCorrect predictions:", int(results["correct"].sum()))
print("Incorrect predictions:", int((~results["correct"]).sum()))
