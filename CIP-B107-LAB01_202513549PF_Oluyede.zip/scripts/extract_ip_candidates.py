import re
import ipaddress
import pandas as pd
from pathlib import Path

BASE = Path("working/extracted/IP_Identifier_Fine_Tuning/code")
INPUT = BASE / "dataset_small.csv"
OUTPUT = Path("results/candidate_reviews/candidate_review.csv")

# Four decimal-number groups separated by periods.
# This detects IPv4-shaped text, not necessarily valid IPv4 addresses.
IPV4_REGEX = re.compile(
    r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])"
)

def validate_ipv4(candidate):
    try:
        ipaddress.IPv4Address(candidate)
        return True, "Valid IPv4"
    except ipaddress.AddressValueError:
        return False, "Invalid IPv4"

df = pd.read_csv(INPUT)
results = []

for row_number, row in df.iterrows():
    source_class = str(row["class"]).strip()
    source_label = "negative" if source_class == "N" else "positive"

    for field in ["ip", "text"]:
        value = str(row[field])

        for match in IPV4_REGEX.finditer(value):
            candidate = match.group(0)
            valid, validation_result = validate_ipv4(candidate)

            results.append({
                "source_row": row_number + 2,
                "source_field": field,
                "candidate": candidate,
                "regex_match": True,
                "ipv4_valid": valid,
                "validation_result": validation_result,
                "source_class": source_class,
                "source_label": source_label,
                "source_text": value
            })

output = pd.DataFrame(results)
output.to_csv(OUTPUT, index=False)

print("IP CANDIDATE EXTRACTION SUMMARY")
print("=" * 50)
print(f"Input CSV records: {len(df)}")
print(f"Total regex candidates: {len(output)}")
print(f"Valid IPv4 candidates: {output['ipv4_valid'].sum()}")
print(f"Invalid IPv4 candidates: {(~output['ipv4_valid']).sum()}")
print(f"Positive-labelled candidates: {(output['source_label'] == 'positive').sum()}")
print(f"Negative-labelled candidates: {(output['source_label'] == 'negative').sum()}")
print(f"Output: {OUTPUT}")

print("\nVALIDATION BREAKDOWN:")
print(output["validation_result"].value_counts().to_string())

print("\nFIRST 15 CANDIDATES:")
print(output[[
    "source_row", "source_field", "candidate",
    "ipv4_valid", "source_class", "source_label"
]].head(15).to_string(index=False))
