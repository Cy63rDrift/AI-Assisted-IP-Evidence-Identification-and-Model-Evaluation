import csv
import hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

base = Path.home() / "icdfaDF/CIP-B107-LAB01"

files = [
    base / "originals/IP_Identifier_Fine_Tuning.zip",
    base / "working/extracted/IP_Identifier_Fine_Tuning/code/dataset_small.csv",
    base / "working/extracted/IP_Identifier_Fine_Tuning/code/dataset_train.jsonl",
    base / "working/extracted/IP_Identifier_Fine_Tuning/code/dataset_test.jsonl",
    base / "working/extracted/IP_Identifier_Fine_Tuning/code/result.csv",
    base / "working/extracted/IP_Identifier_Fine_Tuning/code/fine_tuning_steps.txt",
]

collection_time = datetime.now(ZoneInfo("Africa/Lagos")).isoformat()

output = base / "evidence_manifest.csv"

with output.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=[
        "filename",
        "evidence_path",
        "sha256",
        "file_size_bytes",
        "collection_time_wat",
        "source_modified_time",
        "transfer_source",
        "examiner"
    ])

    writer.writeheader()

    for path in files:
        if not path.is_file():
            raise FileNotFoundError(path)

        digest = hashlib.sha256(path.read_bytes()).hexdigest()

        writer.writerow({
            "filename": path.name,
            "evidence_path": str(path.relative_to(base)),
            "sha256": digest,
            "file_size_bytes": path.stat().st_size,
            "collection_time_wat": collection_time,
            "source_modified_time": datetime.fromtimestamp(
                path.stat().st_mtime,
                ZoneInfo("UTC")
            ).isoformat(),
            "transfer_source": "ICDFA E-Campus supplied materials; downloaded ZIP",
            "examiner": "oluyede tobi"
        })

print(f"Manifest created: {output}")
print(f"Evidence records: {len(files)}")
print(f"Collection time (WAT): {collection_time}")
