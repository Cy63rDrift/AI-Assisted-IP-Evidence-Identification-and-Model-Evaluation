# Phase D: Historical Fine-Tuning Analysis

## 1. Objective
Examine the supplied historical fine-tuning records and document training, validation and classification metrics.

## 2. Evidence examined
- `fine_tuning_steps.txt`
- `result.csv`

The `result.csv` file contains 733 records, ending at step 733.

## 3. Final recorded metrics

| Metric | Final recorded value |
|---|---:|
| Training loss | 0.003727 |
| Training sequence accuracy | 1.0000 |
| Training token accuracy | 1.0000 |
| Validation loss | 0.001895 |
| Validation sequence accuracy | 1.0000 |
| Validation token accuracy | 1.0000 |
| Classification accuracy | 0.978261 |
| Classification precision | 0.971429 |
| Classification recall | 1.000000 |
| AUROC | 0.997549 |
| AUPRC | 0.999147 |
| F1 score | 0.985507 |

## 4. Observations
The historical records show low final training and validation loss and 100% recorded sequence and token accuracy. The final non-null classification accuracy is approximately 97.83%, with an F1 score of approximately 98.55%.

These values describe the historical fine-tuning run. They must not be confused with the independent offline model results from Phase C.

## 5. Limitations
The supplied files do not, by themselves, establish the exact independence of the historical validation and classification evaluation data. The historical metrics therefore cannot be treated as directly comparable with Phase C's supplied test-set results.

The historical metrics are reported as recorded and have not been independently reproduced.

## 6. Charts
- `results/charts/historical_loss.png`
- `results/charts/historical_accuracy.png`
